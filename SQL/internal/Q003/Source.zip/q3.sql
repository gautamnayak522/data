SELECT * FROM Product
SELECT * FROM Users
SELECT * FROM Orders
SELECT * FROM Discount
SELECT * FROM OrderItem

CREATE PROCEDURE PRC1
AS
	BEGIN

		DECLARE @myjson NVARCHAR(MAX)
		SET @myjson = '
		[
        {

           "ProductID": "4",

            "UserID":"2",

           "Qty": "2",

           "OrderDate": "2022-07-08"

        },

        {

           "ProductID": "3",

			"UserID":"2",

           "Qty": "2",

           "OrderDate": "2022-07-08"

        } 
		]
'

		INSERT INTO Orders(UserId,OrderDate)
		SELECT UserID,OrderDate FROM OPENJSON(@myjson)
		WITH (
				UserID INT '$.UserID',
				OrderDate date '$.OrderDate'
		)

	

		INSERT INTO OrderItem(ProductID,OrderId,Qty)
		SELECT UserID,OrderDate FROM OPENJSON(@myjson)
		WITH (
				ProductID INT '$.ProductID',
				OrderId INT , 
				Qty INT '$.Qty'
		)
	END


	EXECUTE PRC1
